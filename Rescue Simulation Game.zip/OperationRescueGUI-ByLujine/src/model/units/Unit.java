package model.units;

import exceptions.CannotTreatException;
import exceptions.IncompatibleTargetException;
import model.disasters.Collapse;
import model.disasters.Disaster;
import model.disasters.Fire;
import model.disasters.GasLeak;
import model.disasters.Infection;
import model.disasters.Injury;
import model.events.SOSResponder;
import model.events.WorldListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import simulation.Address;
import simulation.Rescuable;
import simulation.Simulatable;

public abstract class Unit implements Simulatable, SOSResponder {
	private String unitID;
	private UnitState state;
	private Address location;
	private Rescuable target;
	private int distanceToTarget;
	private int stepsPerCycle;
	private WorldListener worldListener;

	public Unit(String unitID, Address location, int stepsPerCycle,
			WorldListener worldListener) {
		this.unitID = unitID;
		this.location = location;
		this.stepsPerCycle = stepsPerCycle;
		this.state = UnitState.IDLE;
		this.worldListener = worldListener;
	}

	public void setWorldListener(WorldListener listener) {
		this.worldListener = listener;
	}

	public WorldListener getWorldListener() {
		return worldListener;
	}

	public UnitState getState() {
		return state;
	}

	public void setState(UnitState state) {
		this.state = state;
	}

	public Address getLocation() {
		return location;
	}

	public void setLocation(Address location) {
		this.location = location;
	}

	public String getUnitID() {
		return unitID;
	}

	public Rescuable getTarget() {
		return target;
	}

	public int getStepsPerCycle() {
		return stepsPerCycle;
	}

	public void setDistanceToTarget(int distanceToTarget) {
		this.distanceToTarget = distanceToTarget;
	}

	
	public void respond(Rescuable r) throws IncompatibleTargetException, CannotTreatException{
		if(((this instanceof Evacuator) && (r instanceof ResidentialBuilding)) ||
				((this instanceof FireTruck) && (r instanceof ResidentialBuilding)) ||
				((this instanceof GasControlUnit) && (r instanceof ResidentialBuilding))) {
			if(this.canTreat(r) == false) 
				throw new CannotTreatException(this, r, "citizen is already safe");
			else {
				if (target != null && state == UnitState.TREATING)
					reactivateDisaster();
				finishRespond(r);
			}
		}
		else 
			throw new IncompatibleTargetException(this, r, "this unit is incompatible with this target");
	}
		

	public void reactivateDisaster() {
		Disaster curr = target.getDisaster();
		curr.setActive(true);
	}

	public void finishRespond(Rescuable r) {
		target = r;
		state = UnitState.RESPONDING;
		Address t = r.getLocation();
		distanceToTarget = Math.abs(t.getX() - location.getX())
				+ Math.abs(t.getY() - location.getY());
	}

	public abstract void treat();

	public void cycleStep() {
		if (state == UnitState.IDLE)
			return;
		if (distanceToTarget > 0) {
			distanceToTarget = distanceToTarget - stepsPerCycle;
			if (distanceToTarget <= 0) {
				distanceToTarget = 0;
				Address t = target.getLocation();
				worldListener.assignAddress(this, t.getX(), t.getY());
			}
		} 
		else {
			treat();
			state = UnitState.TREATING;
		}
	}

	public void jobsDone() {
		target = null;
		state = UnitState.IDLE;
	}
	
	public boolean canTreat(Rescuable r) {
		if(r instanceof ResidentialBuilding) {
			if(r.getDisaster() instanceof Collapse && !(this instanceof Evacuator)
					|| r.getDisaster() instanceof Fire && !(this instanceof FireTruck) 
					|| r.getDisaster() instanceof GasLeak && !(this instanceof GasControlUnit)) 
				return false;
			ResidentialBuilding b = (ResidentialBuilding) r;
			if(b.getFireDamage() == 0 && b.getFoundationDamage() == 0 && b.getGasLevel() == 0)
				return false;
		}
		else if(r instanceof Citizen) {
			if(r.getDisaster() instanceof Injury && !(this instanceof Ambulance) || r.getDisaster() instanceof Infection && !(this instanceof DiseaseControlUnit)){
				return false;	
			}
			Citizen c = (Citizen) r;
			if(c.getBloodLoss()== 0 && c.getToxicity() == 0) {
				return false;
			}
		}
		return true;
	}
	public String returnUnit() {
		String s="\n"+"ID:"+ unitID+ "\n"+ "Type: ";
		
		
		if(this instanceof Evacuator) {
			s+= " Evacuator"+ "\n"+  "Location: (" +location.getX() +"," +location.getY()+ ")" +"\n"+
		"Steps per cycle: "+ stepsPerCycle +checkTarget()+"\n"+ "State: "+ state +"\n"+ "# of passengers: "
		+((Evacuator)this).getPassengers().size();
	}
		else if(this instanceof FireTruck) {
			s+= " Fire Truck"+ "\n"+  "Location: (" +location.getX() +"," +location.getY()+ ")" +"\n"+
		"Steps per cycle: "+ stepsPerCycle+checkTarget() +"\n"+ "State: "+ state;
	}
		else if(this instanceof GasControlUnit) {
			s+= " Gas control unit"+ "\n"+  "Location: (" +location.getX() +"," +location.getY()+ ")" +"\n"+
		"Steps per cycle: "+ stepsPerCycle +checkTarget()+"\n"+ "State: "+ state;
	}
		else if(this instanceof Ambulance) {
			s+= " Ambulance"+ "\n"+  "Location: (" +location.getX() +"," +location.getY()+ ")" +"\n"+
		"Steps per cycle: "+ stepsPerCycle +checkTarget() +"\n"+ "State: "+ state;
	}
		else if(this instanceof DiseaseControlUnit) {
			s+= " Disease Control Unit"+ "\n"+  "Location: (" +location.getX() +"," +location.getY()+ ")" +"\n"+
		"Steps per cycle: "+ stepsPerCycle +checkTarget() +"\n"+ "State: "+ state;
	}
		
		return s;
		
}
	
	public String checkTarget()
	{
		if(this.target == null)
		{
			return"";
		}
		
		return "\n"+ "Target: "+target +"\n"+ "Target's Location:( "  +target.getLocation().getX() +"," 
		+target.getLocation().getY()+ ")";
	}

}
