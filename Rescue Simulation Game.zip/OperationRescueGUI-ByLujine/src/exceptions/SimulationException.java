package exceptions;

abstract public class SimulationException extends Exception{

	public SimulationException() {
	}
	public SimulationException(String message){
		
	}
}
