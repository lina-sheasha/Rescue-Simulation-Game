package controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import exceptions.BuildingAlreadyCollapsedException;
import exceptions.CannotTreatException;
import exceptions.CitizenAlreadyDeadException;
import exceptions.IncompatibleTargetException;
import model.disasters.Fire;
import model.events.SOSListener;
import model.infrastructure.ResidentialBuilding;
import model.people.Citizen;
import model.people.CitizenState;
import model.units.Ambulance;
import model.units.DiseaseControlUnit;
import model.units.Evacuator;
import model.units.FireTruck;
import model.units.GasControlUnit;
import model.units.Unit;
import simulation.Rescuable;
import simulation.Simulator;
import view.Game;
import view.GameOver;
import view.Start;

public class CommandCenter implements SOSListener, ActionListener{

	private Simulator engine;
	private Start game;
	private GameOver x;
	private ArrayList<ResidentialBuilding> visibleBuildings;
	private ArrayList<Citizen> visibleCitizens;

	@SuppressWarnings("unused")
	private ArrayList<Unit> emergencyUnits;
	public Rescuable lastClickedTarget;
	public Unit lastClickedUnit;

	public ArrayList<Unit> getEmergencyUnits() 
	{
		return emergencyUnits;
	}

	public CommandCenter() throws Exception 
	{
		engine = new Simulator(this);
		visibleBuildings = new ArrayList<ResidentialBuilding>();
		visibleCitizens = new ArrayList<Citizen>();
		emergencyUnits = engine.getEmergencyUnits();
		game = new Start();
		game.nextCycle.addActionListener(this);
		game.respond.addActionListener(this);
	}
	
	public void updateGrid()
	{
		JButton [][] buttons = game.buttons;
			
		for(int i = 0 ; i<visibleBuildings.size();i++)
		{
			int x = visibleBuildings.get(i).getLocation().getX();
			int y = visibleBuildings.get(i).getLocation().getY();
			if(visibleBuildings.get(i).getStructuralIntegrity() != 0)
			{
				if(visibleBuildings.get(i).getDisaster().isActive()) {
					JButton building = new JButton("building");
					building.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
					building.setBackground(Color.green);
					building.setBorderPainted(false);
					building.addActionListener(this);
					ResidentialBuilding b = visibleBuildings.get(i);
					building.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							game.info.setText( "Info Panel: " + b.returnBuildingInfo());	
							popBuilding(b);
							lastClickedTarget = b;
						}
					});
					buttons[x][y].removeAll();
					buttons[x][y].add(building);
					buttons[x][y].setBackground(Color.green);
				}
				else {
					JButton building = new JButton("building");
					building.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
					building.setBackground(Color.white);
					building.setBorderPainted(false);
					building.addActionListener(this);
					ResidentialBuilding b = visibleBuildings.get(i);
					building.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							game.info.setText( "Info Panel: " + b.returnBuildingInfo());	
							popBuilding(b);
							lastClickedTarget = b;
						}
					});
					buttons[x][y].removeAll();
					buttons[x][y].add(building);
					}
			}
			else
			{
				JButton building = new JButton("Collapsed!");
				building.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 40));
				building.setBackground(Color.red);
				building.setBorderPainted(false);
				building.addActionListener(this);
				ResidentialBuilding b = visibleBuildings.get(i);
				building.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " + b.returnBuildingInfo());	
						popBuilding(b);
						lastClickedTarget = b;
					}
				});
				buttons[x][y].removeAll();
				buttons[x][y].add(building);
				buttons[x][y].setBackground(Color.red);
			}
		}
		
		for(int i = 0 ; i<visibleCitizens.size();i++)
		{
			int x = visibleCitizens.get(i).getLocation().getX();
			int y = visibleCitizens.get(i).getLocation().getY();
			if(visibleCitizens.get(i).getState() != CitizenState.DECEASED)
			{
				if(visibleCitizens.get(i).getDisaster().isActive()) {
					JButton citizen = new JButton("citizen");
					citizen.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
					citizen.setBackground(Color.blue);
					citizen.setForeground(Color.white);
					citizen.setBorderPainted(false);
					Citizen c = visibleCitizens.get(i);
					citizen.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							game.info.setText( "Info Panel: " + c.returnCitizenInfo());
							lastClickedTarget = c;
						}
					});
					buttons[x][y].removeAll();
					buttons[x][y].setBackground(Color.blue);
					buttons[x][y].add(citizen);
				}
				else {
					JButton citizen = new JButton("citizen");
					citizen.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
					citizen.setBackground(Color.white);
					citizen.setBorderPainted(false);
					Citizen c = visibleCitizens.get(i);
					citizen.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							game.info.setText( "Info Panel: " + c.returnCitizenInfo());
							lastClickedTarget = c;
						}
					});
					buttons[x][y].removeAll();
					buttons[x][y].setBackground(Color.blue);
					buttons[x][y].add(citizen);
					}
			}
			else
			{
				JButton citizen = new JButton("Dead!");
				citizen.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				citizen.setBackground(Color.red);
				citizen.setBorderPainted(false);
				Citizen c = visibleCitizens.get(i);
				citizen.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " + c.returnCitizenInfo());
						lastClickedTarget = c;
					}
				});
				buttons[x][y].removeAll();
				buttons[x][y].setBackground(Color.red);
				buttons[x][y].add(citizen);
				
			}
		}
		
		for(int i = 0 ; i<emergencyUnits.size();i++)
		{
			int x = emergencyUnits.get(i).getLocation().getX();
			int y = emergencyUnits.get(i).getLocation().getY();
			
			 if(emergencyUnits.get(i) instanceof Ambulance)
			{

				 JButton ambulance = new JButton("Ambulance");
				 ambulance.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				 ambulance.setBackground(Color.white);
				 ambulance.setBorderPainted(false);
					Unit u = emergencyUnits.get(i);
					ambulance.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							u.returnUnit();
							lastClickedUnit = u;
						}
					});
					buttons[x][y].add(ambulance);
			}
			
			else if(emergencyUnits.get(i) instanceof FireTruck)
			{
				 JButton fireTruck = new JButton("Fire Truck");
				 fireTruck.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				 fireTruck.setBackground(Color.white);
				 fireTruck.setBorderPainted(false);
					Unit u = emergencyUnits.get(i);
					fireTruck.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							u.returnUnit();
							lastClickedUnit = u;
						}
					});
					buttons[x][y].add(fireTruck);
			}
			
			else if(emergencyUnits.get(i) instanceof DiseaseControlUnit)
			{

				 JButton diseaseControlUnit = new JButton("Disease Control Unit");
				 diseaseControlUnit.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				 diseaseControlUnit.setBackground(Color.white);
				 diseaseControlUnit.setBorderPainted(false);
					Unit u = emergencyUnits.get(i);
					diseaseControlUnit.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							u.returnUnit();
							lastClickedUnit = u;
						}
					});
					buttons[x][y].add(diseaseControlUnit);
			}
			
			else if(emergencyUnits.get(i) instanceof GasControlUnit)
			{

				 JButton gasControlUnit = new JButton("Gas Control Unit");
				 gasControlUnit.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				 gasControlUnit.setBackground(Color.white);
				 gasControlUnit.setBorderPainted(false);
					Unit u = emergencyUnits.get(i);
					gasControlUnit.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							u.returnUnit();
							lastClickedUnit = u;
						}
					});
					buttons[x][y].add(gasControlUnit);
			} 
			
			else if(emergencyUnits.get(i) instanceof Evacuator)
			{

				 JButton evacuator = new JButton("Evacuator");
				 evacuator.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
				 evacuator.setBackground(Color.white);
				 evacuator.setBorderPainted(false);
					Unit u = emergencyUnits.get(i);
					evacuator.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							u.returnUnit();
							lastClickedUnit = u;
						}
					});
					buttons[x][y].add(evacuator);
			} 
			
		}
	
		game.buttons = buttons;
		game.addButtonsToPannel();
		game.validate();
		game.repaint();
	}
	
	public void updateUnits()
	{	
		JButton ambulance = new JButton();
		JButton evacuator = new JButton();
		JButton fireTruck = new JButton();
		JButton gasControlUnit= new JButton();
		JButton diseaseControlUnit = new JButton();
		
		for(int i = 0 ; i < emergencyUnits.size() ;i++)
		{
			if(emergencyUnits.get(i) instanceof Ambulance) 
			{
				ambulance = new JButton("ambulance");
				ambulance.setFont(new Font("Times New Roman", Font.BOLD, 50));
				ambulance.setBackground(Color.black);
				ambulance.setForeground(Color.white);
				ambulance.setBorderPainted(false);
				game.ambulance.add(ambulance);
				Unit u = emergencyUnits.get(i);
				ambulance.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " + u.returnUnit());
						lastClickedUnit = u;
					}
				});
				
			}
			else if(emergencyUnits.get(i) instanceof DiseaseControlUnit) {
			
				diseaseControlUnit = new JButton("disease control");
				diseaseControlUnit.setFont(new Font("Times New Roman", Font.BOLD, 50));
				diseaseControlUnit.setBackground(Color.black);
				diseaseControlUnit.setForeground(Color.white);
				diseaseControlUnit.setBorderPainted(false);
				game.dcu.add(diseaseControlUnit);
				Unit u = emergencyUnits.get(i);
				diseaseControlUnit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " +u.returnUnit() );
						lastClickedUnit = u;
					}
				});
			}
			else if(emergencyUnits.get(i) instanceof GasControlUnit) {
				gasControlUnit = new JButton("gas Unit");
				gasControlUnit.setFont(new Font("Times New Roman", Font.BOLD, 50));
				gasControlUnit.setBackground(Color.black);
				gasControlUnit.setForeground(Color.white);
				gasControlUnit.setBorderPainted(false);
				game.gc.add(gasControlUnit);
				Unit u = emergencyUnits.get(i);
				gasControlUnit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " +u.returnUnit() );
						lastClickedUnit = u;
					}
				});
			}
			else if (emergencyUnits.get(i) instanceof Evacuator) {
				evacuator = new JButton("evacuator");
				evacuator.setFont(new Font("Times New Roman", Font.BOLD, 50));
				evacuator.setBackground(Color.black);
				evacuator.setForeground(Color.white);
				evacuator.setBorderPainted(false);
				game.evacuator.add(evacuator);
				Unit u = emergencyUnits.get(i);
				evacuator.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " +u.returnUnit() );
						lastClickedUnit = u;
						popEvacuator((Evacuator)u);
					}
				});
			}
			else if(emergencyUnits.get(i) instanceof FireTruck) {
				fireTruck = new JButton("firetruck");
				fireTruck.setFont(new Font("Times New Roman", Font.BOLD, 50));
				fireTruck.setBackground(Color.black);
				fireTruck.setForeground(Color.white);
				fireTruck.setBorderPainted(false);
				game.firetruck.add(fireTruck);
				Unit u = emergencyUnits.get(i);
				fireTruck.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " +u.returnUnit() );
						lastClickedUnit = u;
					}
				});
				
			}
		}
		
		game.validate();
		game.repaint();
	}
		
	public void updateCurrentCycle()
	{
		JTextArea t= new JTextArea("" + engine.getCurrentCycle());
		t.setBackground(Color.black);
		t.setForeground(Color.white);
		game.currentCycle.setText( "Current Cycle: " +t.getText());
		game.validate();
		game.repaint();
	}
	
	public void updateCasualities()
	{
		game.casualities.setText("Casualities: " + engine.calculateCasualties());
		game.validate();
		game.repaint();
	}
	
	@Override
	public void receiveSOSCall(Rescuable r) 
	{
		if (r instanceof ResidentialBuilding) {
			
			if (!visibleBuildings.contains(r))
				visibleBuildings.add((ResidentialBuilding) r);
			
		} else {
			
			if (!visibleCitizens.contains(r))
				visibleCitizens.add((Citizen) r);
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == game.nextCycle)
		{
			if(engine.checkGameOver()) {
				game.setVisible(false);
				x = new GameOver();
				int cas =  engine.calculateCasualties();
				x.noofcas.setText("Number Of Casualities" + cas);
			}
			
			try 
			{
				engine.nextCycle();
			System.out.println(1);
			} 
			catch (CitizenAlreadyDeadException | BuildingAlreadyCollapsedException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
		
				JOptionPane.showMessageDialog(game, e1.toString());	
			}
				
			if(engine.getCurrentCycle() == 1) {
				updateUnits();
			}
			updateGrid();
			updateCurrentCycle();
			updateCasualities();
			deadCitizens();
			updateDisasters();
			compoundCell();
			activeDisasters();
		}
			else if(e.getSource() == game.respond) {
				if(lastClickedTarget != null && lastClickedUnit != null)
				{
					try {
						lastClickedUnit.respond(lastClickedTarget);
					} 
					catch (IncompatibleTargetException | CannotTreatException e1) {
						// TODO Auto-generated catch block
//						e1.printStackTrace();
						JOptionPane.showMessageDialog(game, e1.toString());			
					}
				}
			}
		}
	
	public void updateDisasters() 
	{
		String s = "";
		s+="The Disasters: " + "\n";
		for(int i = 0 ; i<engine.getExecutedDisasters().size();i++)
		{
			s+=engine.getExecutedDisasters().get(i).toString() + "  on   " + engine.getExecutedDisasters().get(i).getTarget().toString();
			s+="\n";
		}
		game.disasters.setText(s);
	}
	
	public void popCompound(ArrayList<Object> b) 
	{
		JDialog j= new JDialog();
		j.setLayout(new FlowLayout());
		j.setSize( 700,300 );
		JPanel p= new JPanel();
		p.setLayout(new FlowLayout());
		JLabel l= new JLabel();
		p.add(l);
		j.add(p, BorderLayout.CENTER);
		
		for(int i=0;i<b.size();i++) 
		{
			if(b.get(i) instanceof Citizen)
			{
				JButton citizen = new JButton("Citizen");
				citizen.setBackground(Color.cyan);
				citizen.setFont(new Font("Times New Roman",Font.BOLD, 50));
				//l.add(citizen);
				Citizen c= (Citizen) b.get(i);
				citizen.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						game.info.setText( "Info Panel: " + c.returnCitizenInfo());
						lastClickedTarget = c;
					}
				});
				j.add(citizen);
			}
			else if(b.get(i) instanceof ResidentialBuilding)
			{
				JButton building= new JButton("Building");
				building.setBackground(Color.orange);
				building.setFont(new Font("Times New Roman",Font.BOLD, 50));
				//l.add(building);
				ResidentialBuilding c= (ResidentialBuilding) b.get(i);
				building.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {	
						game.info.setText( "Info Panel: " + c.returnBuildingInfo());
						lastClickedTarget = c;
					}
				});	
				j.add(building);	
			}
			else if(b.get(i) instanceof Ambulance)
			{
				JButton ambulance= new JButton("Ambulance");
				ambulance.setBackground(Color.orange);
				ambulance.setFont(new Font("Times New Roman",Font.BOLD, 50));
			//	l.add(ambulance);
				Ambulance c= (Ambulance) b.get(i);
				ambulance.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnUnit());
						lastClickedUnit = c;
					}
				});	
				j.add(ambulance);	
			}
			else if(b.get(i) instanceof FireTruck)
			{
				JButton fireTruck= new JButton("Fire Truck");
				fireTruck.setBackground(Color.orange);
				fireTruck.setFont(new Font("Times New Roman",Font.BOLD, 50));
				//l.add(fireTruck);
				FireTruck c= (FireTruck) b.get(i);
				fireTruck.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnUnit());
						lastClickedUnit = c;
					}
				});
				
				j.add(fireTruck);
				
			}
			
			else if(b.get(i) instanceof DiseaseControlUnit)
			{
				JButton diseaseControlUnit= new JButton("Disease Control Unit");
				diseaseControlUnit.setBackground(Color.orange);
				diseaseControlUnit.setFont(new Font("Times New Roman",Font.BOLD, 50));
				//l.add(diseaseControlUnit);
				DiseaseControlUnit c= (DiseaseControlUnit) b.get(i);
				diseaseControlUnit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnUnit());
						lastClickedUnit = c;
					}
				});
				
				j.add(diseaseControlUnit);
				
			}
			
			else if(b.get(i) instanceof GasControlUnit)
			{
				JButton gasControlUnit= new JButton("Gas Control Unit");
				gasControlUnit.setBackground(Color.orange);
				gasControlUnit.setFont(new Font("Times New Roman",Font.BOLD, 50));
			//	l.add(gasControlUnit);
				GasControlUnit c= (GasControlUnit) b.get(i);
				gasControlUnit.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnUnit());
						lastClickedUnit = c;
					}
				});
				
				j.add(gasControlUnit);
				
			} 
			
			else if(b.get(i) instanceof Evacuator)
			{
				JButton evacuator= new JButton("Evacuator");
				evacuator.setBackground(Color.orange);
				evacuator.setFont(new Font("Times New Roman",Font.BOLD, 50));
			//	l.add(evacuator);
				Evacuator c= (Evacuator) b.get(i);
				evacuator.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnUnit());
						lastClickedUnit = c;
					}
				});
				
				
				j.add(evacuator);
				
			} 
			
			p.add(l);

		}
		
		j.add(p);
		j.setVisible(true);
		j.revalidate();
		j.repaint();
	}
	
//	public void popBuilding(ResidentialBuilding b) {
//		
//			if(b.getOccupants().size()==0)
//			{
//				;
//			}
//			
//			else
//			{
//			JDialog j= new JDialog();
//			j.setLayout(new FlowLayout());
//			j.setSize(800,400);
//			
//			JPanel p= new JPanel();
//			p.setLayout(new FlowLayout());
//			
//			JLabel l= new JLabel();
//			
//			p.add(l);
//			j.add(p, BorderLayout.CENTER);
//			
//			for(int i=0;i<b.getOccupants().size();i++) {
//				
//				if(b.getOccupants().get(i).getState()!=CitizenState.DECEASED)
//				{
//				JButton occupant= new JButton("Occupant");
//				occupant.setBackground(Color.orange);
//				occupant.setFont(new Font("Times New Roman",Font.BOLD, 50));
//				p.add(occupant);
//				Citizen c= b.getOccupants().get(i);
//				occupant.addActionListener(new ActionListener() {
//					@Override
//					public void actionPerformed(ActionEvent e) {
//						
//						game.info.setText( "Info Panel: " + c.returnCitizenInfo());
//						lastClickedTarget = c;
//					}
//				});
//				
//				j.add(occupant);
//				}
//				
//				else
//				{
//					
//					JButton occupant= new JButton("Dead!");
//					occupant.setBackground(Color.red);
//					occupant.setFont(new Font("Times New Roman",Font.BOLD, 50));
//					p.add(occupant);
//					Citizen c= b.getOccupants().get(i);
//					occupant.addActionListener(new ActionListener() {
//						@Override
//						public void actionPerformed(ActionEvent e) {
//							
//							game.info.setText( "Info Panel: " + c.returnCitizenInfo());
//							lastClickedTarget = c;
//						}
//					});
//					
//					j.add(occupant);
//					
//					
//				}
//			}
//			
//			j.setVisible(true);
//			}
//			game.repaint();
//			game.validate();
//			
//			
//	}
	public void popBuilding(ResidentialBuilding b) {
		
		if(b.getOccupants().size()==0)
		{
			;
		}
		
		else
		{
		JDialog j= new JDialog();
		j.setLayout(new FlowLayout());
		j.setSize( 700,300 );
		
		JPanel p= new JPanel();
		p.setLayout(new FlowLayout());
		
		JLabel l= new JLabel();
		
		p.add(l);
		j.add(p, BorderLayout.CENTER);
		
		for(int i=0;i<b.getOccupants().size();i++) {
			
			if(b.getOccupants().get(i).getState()!=CitizenState.DECEASED)
			{
			JButton occupant= new JButton("Occupant");
			occupant.setBackground(Color.orange);
			occupant.setFont(new Font("Times New Roman",Font.BOLD, 50));
			p.add(occupant);
			Citizen c= b.getOccupants().get(i);
			occupant.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					
					game.info.setText( "Info Panel: " + c.returnCitizenInfo());
					lastClickedTarget = c;
				}
			});
			
			j.add(occupant);
			}
			
			else
			{
				
				JButton occupant= new JButton("Dead!");
				occupant.setBackground(Color.red);
				occupant.setFont(new Font("Times New Roman",Font.BOLD, 50));
				p.add(occupant);
				Citizen c= b.getOccupants().get(i);
				occupant.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnCitizenInfo());
						lastClickedTarget = c;
					}
				});
				
				j.add(occupant);
				
				
			}
		}
		
		j.setVisible(true);
		}
		
}

	
	public void popEvacuator(Evacuator e ) {
		if(e.getPassengers().size()==0)
		{
			;
		}
		
		else
		{
		JDialog j= new JDialog();
		j.setLayout(new FlowLayout());
		j.setSize( 700,300 );
		
		JPanel p= new JPanel();
		p.setLayout(new FlowLayout());
		
		JLabel l= new JLabel();
		
		p.add(l);
		j.add(p, BorderLayout.CENTER);
		
		for(int i=0;i<e.getPassengers().size();i++) {
			
			if(e.getPassengers().get(i).getState() != CitizenState.DECEASED)
			{
			JButton passenger= new JButton("Passengers");
			passenger.setBackground(Color.orange);
			passenger.setFont(new Font("Times New Roman",Font.BOLD, 50));
			p.add(passenger);
			Citizen c= e.getPassengers().get(i);
			passenger.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					
					game.info.setText( "Info Panel: " + c.returnCitizenInfo());
					lastClickedTarget = c;
				}
			});
			
			j.add(passenger);
			}
			
			else
			{
				JButton passenger= new JButton("Dead!");
				passenger.setBackground(Color.red);
				passenger.setFont(new Font("Times New Roman",Font.BOLD, 50));
				p.add(passenger);
				Citizen c= e.getPassengers().get(i);
				passenger.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						
						game.info.setText( "Info Panel: " + c.returnCitizenInfo());
						lastClickedTarget = c;
					}
				});
				
				j.add(passenger);
			}
		}
		
		j.setVisible(true);
		}	
}
	
	public void compoundCell() 
	{
		for(int i = 0 ; i < 10 ; i++)
		{
			for(int j = 0 ; j <10 ; j++)
			{
				ArrayList<Object> objects = new ArrayList<Object>();
//				objects.clear();
				for(int l = 0 ; l < visibleBuildings.size();l++)
				{
					int x = visibleBuildings.get(l).getLocation().getX();
					int y = visibleBuildings.get(l).getLocation().getY();
					if(x==i && y==j)
					{
						objects.add(visibleBuildings.get(l));
					}
				}
				
				for(int s = 0 ; s < visibleCitizens.size() ; s++)
				{
					int x = visibleCitizens.get(s).getLocation().getX();
					int y = visibleCitizens.get(s).getLocation().getY();
					if(x==i && y==j)
					{
						objects.add(visibleCitizens.get(s));
					}
				}
				
				for(int g = 0 ; g < emergencyUnits.size() ;g++)
				{
					int x = emergencyUnits.get(g).getLocation().getX();
					int y = emergencyUnits.get(g).getLocation().getY();
					if(x==i && y==j)
					{
						objects.add(emergencyUnits.get(g));
					}
				}
				
				
				if(objects.size()>1)
				{
					JButton CB = new JButton("CMPB");
					CB.setFont(new Font("Times New Roman", Font.CENTER_BASELINE, 50));
					CB.setBackground(Color.white);
					CB.setBorderPainted(false);
					game.buttons[i][j].removeAll();
					game.buttons[i][j].add(CB);
					CB.addActionListener(new ActionListener() {
						@Override
						public void actionPerformed(ActionEvent e) {
							popCompound(objects);
						}
					});
					
				}
			}
			
		}
	}
	
	public void activeDisasters()
	{
		String s = "";
		s+="The Active Disasters: " + "\n";
		for(int i = 0 ; i<engine.getExecutedDisasters().size();i++)
		{
			if(engine.getExecutedDisasters().get(i).isActive())
			{	
			s+=engine.getExecutedDisasters().get(i).toString();
			s+="\n";
			
			}
		}
		game.activeDisasters.setText(s);
	}
	
	public void deadCitizens() 
	{	
		String s = "Dead Citizens: " + "\n";
		for(int k = 0 ; k < visibleBuildings.size(); k++)
		{
			ResidentialBuilding b = visibleBuildings.get(k);
			for(int m = 0; m< b.getOccupants().size(); m++) 
			{
			if(b.getOccupants().get(m).getState() == CitizenState.DECEASED ) 
			{
				s += b.getOccupants().get(m).getName()+ "  in   " + "(" + b.getOccupants().get(m).getLocation().getX()
						+ "," + b.getOccupants().get(m).getLocation().getY() + ")";
				s+="\n";
			}
			}
		}
		for(int k = 0 ; k < visibleCitizens.size(); k++)
		{
			if(visibleCitizens.get(k).getState() == CitizenState.DECEASED ) 
			{
			s +=visibleCitizens.get(k).getName()+ "  in   " + "(" + visibleCitizens.get(k).getLocation().getX() + "," + visibleCitizens.get(k).getLocation().getY() + ")";
			s +="\n";
			}
		}
	//	System.out.println(s);
		game.deadPeople.setText(s);
	}
	
	
	public static void main(String[]args) throws Exception
	{
		new CommandCenter();
	}
}

