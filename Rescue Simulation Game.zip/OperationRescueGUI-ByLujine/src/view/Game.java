package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import controller.CommandCenter;

public class Game extends JFrame {

	private ImageIcon ai;
	private JLabel al;
	private ImageIcon dci;
	private JLabel dcl;
	private ImageIcon ei;
	private JLabel el;
	private ImageIcon fti;
	private JLabel ftl;
	private ImageIcon gci;
	private JLabel gcl;
	private ImageIcon infoimage;
	private JLabel infolabel;
	private JButton[][] buttons;
	
	public JButton[][] getButtons() {
		return buttons;
	}

	public void setButtons(JButton[][] buttons) {
		this.buttons = buttons;
	}

	public Game() 
	{	
		setSize(2000,1500);
		setTitle("Simulation");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setBackground(Color.darkGray);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		JPanel general = new JPanel();
		general.setBackground(Color.darkGray);
		general.setLayout(new BorderLayout());
		
		JPanel buttonsGrid = new JPanel();
		general.add(buttonsGrid, BorderLayout.CENTER);
		buttonsGrid.setBackground(Color.darkGray);
		buttonsGrid.setLayout(new GridLayout(10,10));
		buttonsGrid.setPreferredSize(new Dimension(getWidth()/5, getHeight()/5));
		
		JPanel unit = new JPanel();
		general.add(unit, BorderLayout.SOUTH);
		unit.setBackground(Color.darkGray);
	//	unit.setLayout(new GridLayout(0,5));
	//	unit.setPreferredSize(new Dimension(getWidth()/2, getHeight()/5));
		
		JPanel info = new JPanel();
		general.add(info, BorderLayout.EAST);
		info.setBackground(Color.darkGray);
		info.setLayout(new FlowLayout());
			
		buttons = new JButton[10][10];
		
		for(int i = 0; i < buttons.length; i++) 
		{
			for(int j = 0; j < buttons[i].length; j++) 
			{
				buttons[i][j] = new JButton("button");
				buttonsGrid.add(buttons[i][j]);
				buttons[i][j].setBackground(Color.white);	
			}
		}
		
		
		JButton ambulance = new JButton();
		ambulance.setBackground(Color.white);
		ai = new ImageIcon(getClass().getResource("images/ambulanceunit.png"));
		al = new JLabel(ai);
		ambulance.add(al);
		ambulance.setBounds(50, 40, 129, 80);
		JButton dcu = new JButton();
		dcu.setBackground(Color.white);
		dci = new ImageIcon(getClass().getResource("images/diseasecontrol.png"));
		dcl = new JLabel(dci);
		dcu.add(dcl);
		dcu.setBounds(50, 40, 129, 80);
		JButton evacuator = new JButton();
		evacuator.setBackground(Color.white);
		ei = new ImageIcon(getClass().getResource("images/evacuator.png"));
		el = new JLabel(ei);
		evacuator.add(el);
		evacuator.setBounds(50, 40, 129, 80);
		JButton gc = new JButton();
		gc.setBackground(Color.white);
		gci = new ImageIcon(getClass().getResource("images/gascontrol.png"));
		gcl = new JLabel(gci);
		gc.add(gcl);
		gc.setBounds(50, 40, 129, 80);
		JButton firetruck = new JButton();
		firetruck.setBackground(Color.white);
		fti = new ImageIcon(getClass().getResource("images/firetruck.png"));
		ftl = new JLabel(fti);
		firetruck.add(ftl);
		firetruck.setBounds(50, 40, 129, 80);
		
		setIconImage(gci.getImage());
		
		unit.add(evacuator);
		unit.add(dcu);
		unit.add(ambulance);
		unit.add(gc);
		unit.add(firetruck);
		
		JButton info2 = new JButton();
		info.add(info2);
		info2.setBackground(Color.darkGray);
		infoimage = new ImageIcon(getClass().getResource("images/info.png"));
		infolabel = new JLabel(infoimage);
		info2.add(infolabel);
		
		getContentPane().add(general);
		validate();
		repaint();
		setVisible(true); 
	}
	
	public static void main (String[] Args) 
	{
		Game m = new Game();
	}

	
	
}
