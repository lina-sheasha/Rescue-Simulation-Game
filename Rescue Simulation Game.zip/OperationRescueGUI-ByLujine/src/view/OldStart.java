//package view;
//
//import java.awt.BorderLayout;
//import java.awt.Color;
//import java.awt.FlowLayout;
//import java.awt.Font;
//import java.awt.GridLayout;
//import java.awt.Toolkit;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import java.util.ArrayList;
//import java.util.Arrays;
//
//import javax.swing.ImageIcon;
//import javax.swing.JButton;
//import javax.swing.JDialog;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JOptionPane;
//import javax.swing.JPanel;
//import javax.swing.JTextArea;
//import javax.swing.WindowConstants;
//
//import controller.CommandCenter;
//import exceptions.BuildingAlreadyCollapsedException;
//import exceptions.CitizenAlreadyDeadException;
//import model.infrastructure.ResidentialBuilding;
//
//
//public class OldStart extends JFrame implements ActionListener {
//
//	//to set the background to transparent, use the method setOpaque(false);
//	
//	private ImageIcon startImage1;
//	private JLabel startlabel1;
//	private ImageIcon startImage2;
//	private JLabel startlabel2;
//	private ImageIcon startimage3;
//	private JLabel startlabel3;
//	private JPanel generalpanel = new JPanel();
//	private JPanel imagepanel = new JPanel();
//	private JPanel buttonpanel = new JPanel();
////	private JPanel p4 = new JPanel();	
//	public JButton startButton = new JButton("Start");
//	public JButton exitButton = new JButton("exit");
//	private JTextArea gametitle;
////	private JLabel enterName;
////	private JTextField name;
////	private String storeName = "";
//	ImageIcon background;
//	JLabel backgroundlabel;
//
//	private ImageIcon ai;
//	private JLabel al;
//	private ImageIcon dci;
//	private JLabel dcl;
//	private ImageIcon ei;
//	private JLabel el;
//	private ImageIcon fti;
//	private JLabel ftl;
//	private ImageIcon iconImage;
//	private JLabel gcl;
//	private ImageIcon infoimage;
//	private JLabel infolabel;
//	private JButton[] buttons;
//	private JPanel buttonsGrid;
//	public JButton nextCycle;
//	public JPanel gamepanel;
//	public JPanel unit;
//	public JPanel information;
//	public CommandCenter c;
//	public JPanel threePanel; 
//	
//	public JPanel getButtonsGrid() {
//		return buttonsGrid;
//	}
//
//	public OldStart(CommandCenter c) {
//		this.c = c;
//		setSize(getWidth(), getHeight());
//		setLocationRelativeTo(null);
//		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		setExtendedState(JFrame.MAXIMIZED_BOTH);
//		start();
//	}
//
//	public void start() 
//	{
//		String fn = JOptionPane.showInputDialog("enter your name");
//		this.setTitle("Misery Town, player: " + fn);
//
//		JDialog d = new JDialog(this, "start game", true);
//		d.setSize(this.getWidth(), this.getHeight());
//		d.setLayout(new BorderLayout());
//		d.setLocationRelativeTo(null);
//		d.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
//		d.setSize(Toolkit.getDefaultToolkit().getScreenSize().width,
//				Toolkit.getDefaultToolkit().getScreenSize().height);
////		p1.setBackground(Color.blue);
//		imagepanel.setBackground(Color.darkGray);
////		p3.setBackground(Color.darkGray);
////		background = new ImageIcon(getClass().getResource("images/background.png"));
////		L1 = new JLabel(background);
////		setContentPane(L1);
////		setUndecorated(true);
////		getContentPane().setBackground(new Color(1.0f, 1.0f, 1.0f, 0.0f));
//		gametitle = new JTextArea();
//		generalpanel.setLayout(new GridLayout(3, 0));
//		buttonpanel.setLayout(new GridLayout(0, 2));
//
//		startImage1 = new ImageIcon(getClass().getResource("images/ambulance.png"));
//		startlabel1 = new JLabel(startImage1);
//
//		startImage2 = new ImageIcon(getClass().getResource("images/wounded.png"));
//		startlabel2 = new JLabel(startImage2);
//
//		startimage3 = new ImageIcon(getClass().getResource("images/burning-house.png"));
//		startlabel3 = new JLabel(startimage3);
//
//		imagepanel.add(startlabel1);
//		imagepanel.add(startlabel2);
//		imagepanel.add(startlabel3);
//
//		startButton.setFont(new Font("Invasion2000", Font.BOLD, 200));
//		startButton.setForeground(Color.black);
//		startButton.setBackground(Color.darkGray);
//		startButton.setBorderPainted(false);
//		startButton.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				game();
//				d.setVisible(false);
//			}
//		});
//
//		exitButton.setFont(new Font("Invasion2000", Font.ITALIC, 200));
//		exitButton.setForeground(Color.black);
//		exitButton.setBackground(Color.darkGray);
//		exitButton.setBorderPainted(false);
//		exitButton.addActionListener(new ActionListener() {
//
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				System.exit(0);
//
//			}
//		});
//
//		iconImage = new ImageIcon(getClass().getResource("images/deericon.jpg"));
//		setIconImage(iconImage.getImage());
//
//		gametitle.setBackground(Color.darkGray);
//		gametitle.setForeground(Color.BLACK);
//		gametitle.setEditable(false);
//		gametitle.setText("misery town");
//		gametitle.setFont(new Font("Spac3 tech", Font.BOLD, 420));
//
//		buttonpanel.add(startButton);
//		buttonpanel.add(exitButton);
//
//		generalpanel.add(gametitle);
//		generalpanel.add(imagepanel);
//		generalpanel.add(buttonpanel);
//
////		p4.add(name);
////		p4.add(enterName);
////		p3.add(p4);
//
//		d.add(generalpanel);
//		d.validate();
//		d.repaint();
//		d.setVisible(true);
//	}
//
//	public void game() 
//	{
//		getContentPane().setBackground(Color.darkGray);
//		gamepanel = new JPanel();
//		gamepanel.setBackground(Color.darkGray);
//		gamepanel.setLayout(new BorderLayout());
//
//		buttonsGrid = new JPanel();
//		gamepanel.add(buttonsGrid, BorderLayout.CENTER);
//		buttonsGrid.setBackground(Color.darkGray);
//		buttonsGrid.setLayout(new GridLayout(10, 10));
//
//		unit = new JPanel();
//		gamepanel.add(unit, BorderLayout.WEST);
//		unit.setBackground(Color.darkGray);
//		unit.setLayout(new GridLayout(5, 0));
//
//		information = new JPanel();
//		gamepanel.add(information, BorderLayout.EAST);
//		information.setBackground(Color.darkGray);
//		information.setLayout(new GridLayout(2,0));
//		
//		components3 = new JPanel();
//		components3.setLayout(new GridLayout(3,0));
//		components3.setBackground(Color.DARK_GRAY);
//		
//		buttons = new JButton[100];
//		for (int i = 0; i < buttons.length; i++) {
//			buttons[i] = new JButton("button");
//			buttons[i].setFont(new Font("Spac3 tech", Font.BOLD, 20));
//			buttons[i].setBackground(Color.white);
//		}
//		addButtonsToPannel();
//		
//		JButton ambulance = new JButton();
//		ambulance.setBackground(Color.white);
//		ai = new ImageIcon(getClass().getResource("images/ambulanceunit.png"));
//		al = new JLabel(ai);
//		ambulance.add(al);
//
//		JButton dcu = new JButton();
//		dcu.setBackground(Color.white);
//		dci = new ImageIcon(getClass().getResource("images/diseasecontrol.png"));
//		dcl = new JLabel(dci);
//		dcu.add(dcl);
//
//		JButton evacuator = new JButton();
//		evacuator.setBackground(Color.white);
//		ei = new ImageIcon(getClass().getResource("images/evacuator.png"));
//		el = new JLabel(ei);
//		evacuator.add(el);
//
//		JButton gc = new JButton();
//		gc.setBackground(Color.white);
//		iconImage = new ImageIcon(getClass().getResource("images/gascontrol.png"));
//		gcl = new JLabel(iconImage);
//		gc.add(gcl);
//
//		JButton firetruck = new JButton();
//		firetruck.setBackground(Color.white);
//		fti = new ImageIcon(getClass().getResource("images/firetruck.png"));
//		ftl = new JLabel(fti);
//		firetruck.add(ftl);
//
//		setIconImage(iconImage.getImage());
//		information.setLayout(new GridLayout(2, 0));
//		unit.add(evacuator);
//		unit.add(dcu);
//		unit.add(ambulance);
//		unit.add(gc);
//		unit.add(firetruck);
//
////		String n = "" + c.getEngine().getCurrentCycle();
////		JLabel currentCycle = new JLabel("current cycle: " + n);
////		System.out.print(n);
////		currentCycle.setFont(new Font("Spac3 tech", Font.CENTER_BASELINE, 40));
////		currentCycle.setBackground(Color.darkGray);
////		
////		JTextArea casualties = new JTextArea();
////		casualties.setEditable(false);
////		casualties.setFont(new Font("Spac3 tech", Font.LAYOUT_LEFT_TO_RIGHT, 40));
////		casualties.setBackground(Color.white);
//		//String x =  "" + c.returnCasualities();
//		//casualties.setText("number of casualties: " + x);
//		//System.out.println(c.getEngine().calculateCasualties());
//	
//		nextCycle = new JButton("next cycle");
//		nextCycle.setBackground(Color.DARK_GRAY);
//		nextCycle.setFont(new Font("Spac3 tech", Font.LAYOUT_LEFT_TO_RIGHT, 50));
////		nextCycle.addActionListener(this);
//
//		JButton info2 = new JButton();
//		components3.add(nextCycle);
////		components3.add(currentCycle);
////		components3.add(casualties);
//		information.add(components3);
//		information.add(info2);
//		info2.setBackground(Color.darkGray);
//		infoimage = new ImageIcon(getClass().getResource("images/info.png"));
//		infolabel = new JLabel(infoimage);
//		info2.add(infolabel);
//		
//		
//		getContentPane().add(gamepanel);
//		validate();
//		repaint();
//		setVisible(true);
//
//		
//	}
//	
//
//
//	public void addButtonsToPannel() {
//		for (int i = 0; i < buttons.length; i++) {
//			buttonsGrid.add(buttons[i]);
//		}
//		repaint();
//		validate();
//
//	}
//
//	public JButton[] getButtons() {
//		return buttons;
//	}
//
//	public void setButtons(JButton[] buttons) {
//		this.buttons = buttons;
//	}
//
//	@Override
//	public void actionPerformed(ActionEvent e) {
//		if (e.getSource() == nextCycle)
//			{
//				try {
//					c.getEngine().nextCycle();
//					
//					ArrayList<ResidentialBuilding> residentialBuildings = c.getVisibleBuildings();
//					
//					for (ResidentialBuilding r : residentialBuildings) {
//						System.out.println(r.getLocation());
//					}
//					
//					//System.out.println("lala");
//				
//					
//				} catch (CitizenAlreadyDeadException | BuildingAlreadyCollapsedException e1) {
//					// TODO add alert
//					System.out.println("catch");
//					
//				}
//				//System.out.println("next cycle");
//				c.updateGrid();
//			}		
//	}
//}