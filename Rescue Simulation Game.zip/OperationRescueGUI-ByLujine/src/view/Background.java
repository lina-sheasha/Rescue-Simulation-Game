package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class Background extends JFrame{
	ImageIcon image;
	JLabel L1;
	
	public Background() {
		
		String fn = JOptionPane.showInputDialog("enter");
	setTitle(fn);
	setSize(getWidth(), getHeight());
	setLocationRelativeTo(null);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setVisible(true);
	setLayout(new BorderLayout());
	
	image = new ImageIcon(getClass().getResource("images/background.png"));
	L1 = new JLabel(image);

	setContentPane(L1);
	setLayout(new FlowLayout());
	
	setSize(500, 500);


	
	}
	
	public static void main(String[] args) {
		Background m = new Background();
		
	}
}
