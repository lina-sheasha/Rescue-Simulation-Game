package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.border.Border;

import model.units.Unit;
import simulation.Rescuable;

public class Start extends JFrame{

	public ImageIcon startImage1;
	public JLabel startlabel1;
	public ImageIcon startImage2;
	public JLabel startlabel2;
	public ImageIcon startimage3;
	public JLabel startlabel3;
	public JPanel generalpanel = new JPanel();
	public JPanel imagepanel = new JPanel();
	public JPanel buttonpanel = new JPanel();
	public JButton startButton = new JButton("Start");
	public JButton exitButton = new JButton("exit");
	public JTextArea gametitle;
	public ImageIcon background;
	public JLabel backgroundlabel;
	public ImageIcon ai;
	public JLabel al;
	public ImageIcon dci;
	public JLabel dcl;
	public ImageIcon ei;
	public JLabel el;
	public ImageIcon fti;
	public JLabel ftl;
	public ImageIcon iconImage;
	public JLabel gcl;
	public ImageIcon infoimage;
	public JLabel infolabel;
	public JButton[][] buttons;
	public JPanel buttonsGrid;
	public JButton nextCycle;
	public JPanel gamepanel;
	public JPanel unit;
	public JPanel information;
	public JPanel threePanel;
	public JPanel components5;
	public JTextArea currentCycle;
	public JTextArea casualities;
	//public JPanel infoButtons;
	public JTextArea info;
	public JPanel ambulance;
	public JPanel dcu;
	public JPanel evacuator;
	public JPanel gc;
	public JPanel firetruck;
	public JTextArea disasters;
	public JButton respond;
	public JTextArea activeDisasters;
	public JTextArea deadPeople;
	ImageIcon image;
	JLabel L1;

	
	public Start() 
	{
		setSize(getWidth(), getHeight());
		//setLocationRelativeTo(null);
		setLocation(50, 50);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
//		setExtendedState(JFrame.MAXIMIZED_BOTH);
		start();
	}
	
	public void start() 
	{
	//	String name = JOptionPane.showInputDialog("enter your name");
		//title
		this.setTitle("Misery Town");
		//icon
		ImageIcon image = new ImageIcon(getClass().getResource("images/zubat.png"));
		setIconImage(image.getImage());
		
		//page
		JDialog d = new JDialog(this, "start game", true);
		d.setSize(this.getWidth(), this.getHeight());
		d.setLayout(new BorderLayout());
		d.setLocation(0, 0);
		d.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		d.setSize(Toolkit.getDefaultToolkit().getScreenSize().width, Toolkit.getDefaultToolkit().getScreenSize().height);
		imagepanel.setBackground(Color.darkGray);
	
		//game title
		gametitle = new JTextArea();
		gametitle.setBackground(Color.darkGray);
		gametitle.setForeground(Color.BLACK);
		gametitle.setEditable(false);
		gametitle.setText("misery town");
		gametitle.setFont(new Font("Spac3 tech", Font.BOLD, 420));
		
		//panel including everything
		
		generalpanel.setLayout(new GridLayout(3, 0));
		
		//buttons at the bottom
		
		buttonpanel.setLayout(new GridLayout(0, 2));

		startButton.setFont(new Font("Invasion2000", Font.BOLD, 200));
		startButton.setForeground(Color.black);
		startButton.setBackground(Color.darkGray);
		startButton.setBorderPainted(false);
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				game();
				d.setVisible(false);
			}
		});

		exitButton.setFont(new Font("Invasion2000", Font.ITALIC, 200));
		exitButton.setForeground(Color.black);
		exitButton.setBackground(Color.darkGray);
		exitButton.setBorderPainted(false);
		exitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		buttonpanel.add(startButton);
		buttonpanel.add(exitButton);
		
		//imagepanel 
		
		startImage1 = new ImageIcon(getClass().getResource("images/ambulance1.png"));
		startlabel1 = new JLabel(startImage1);

		startImage2 = new ImageIcon(getClass().getResource("images/wounded.png"));
		startlabel2 = new JLabel(startImage2);

		startimage3 = new ImageIcon(getClass().getResource("images/burning-house.png"));
		startlabel3 = new JLabel(startimage3);

		imagepanel.add(startlabel1);
		imagepanel.add(startlabel2);
		imagepanel.add(startlabel3);

		
		generalpanel.add(gametitle);
		generalpanel.add(imagepanel);
		generalpanel.add(buttonpanel);
		
		d.add(generalpanel);
		d.validate();
		d.repaint();
		d.setVisible(true);		
	}
	
	public void game() 
	{
		//game icon
		
		ImageIcon image = new ImageIcon(getClass().getResource("images/zubat.png"));
		setIconImage(image.getImage());
		
		getContentPane().setBackground(Color.darkGray);
		
		//general panel 
		
		gamepanel = new JPanel();
		gamepanel.setBackground(Color.darkGray);
		gamepanel.setLayout(new BorderLayout());

		Border outsidegridBorder = BorderFactory.createLineBorder(Color.black,100,true);
		Border insidegridBorder = BorderFactory.createEmptyBorder(200,100,200,100);	
		
		//10x10 grid
		buttonsGrid = new JPanel();
		buttonsGrid.setBorder(BorderFactory.createCompoundBorder(outsidegridBorder,null));
		gamepanel.add(buttonsGrid, BorderLayout.CENTER);
		buttonsGrid.setBackground(Color.black);
		buttonsGrid.setLayout(new GridLayout(10, 10));
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);

		//units panel
		unit = new JPanel();
		gamepanel.add(unit, BorderLayout.WEST);
		//unit.setBackground(Color.darkGray);
		unit.setLayout(new GridLayout(5,0));

//		information panel 
		
		information = new JPanel();
		gamepanel.add(information, BorderLayout.EAST);
	//	information.setBackground(Color.darkGray);
		information.setLayout(new GridLayout(3,0));
		
		components5 = new JPanel();
		components5.setLayout(new GridLayout(4,0));
		components5.setBackground(Color.DARK_GRAY);
		
		buttons = new JButton[10][10];
		for (int i = 0; i < 10; i++) {
			for (int j = 0; j < 10; j++) {
			buttons[i][j] = new JButton();
			buttons[i][j].setBounds((int)(getWidth()*0.2),(int)(getWidth()*0.2),(int)(getWidth()*0.001),(int)(getHeight()*0.001));
			buttons[i][j].setFont(new Font("Times New Roman", Font.BOLD, 20));
			buttons[i][j].setBackground(Color.white);
			buttons[i][j].setSize(20,10);
			}
		}
		addButtonsToPannel();
		
		Border outsideBorder = BorderFactory.createLineBorder(Color.LIGHT_GRAY,6,true);
		Border insideBorder = BorderFactory.createEmptyBorder(20,10,20,10);		
		
		ambulance = new JPanel();
		ai = new ImageIcon(getClass().getResource("images/ambulanceunit.png"));
		al = new JLabel(ai);
		ambulance.add(al);
		ambulance.setBackground(Color.black);
		ambulance.setLayout(new GridLayout(20,1));
		JScrollPane scroll3 = new JScrollPane(ambulance);
		scroll3.setBounds(50, 30, 300, 50);
		scroll3.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll3.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll3.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder ));


		dcu = new JPanel();
		dcu.setBackground(Color.black);
		dcu.setLayout(new GridLayout(20,1));
		ImageIcon dc = new ImageIcon(getClass().getResource("images/diseaseunit.png"));
		dcl = new JLabel(dc);
		dcu.add(dcl);
		JScrollPane scroll4 = new JScrollPane(dcu);
		scroll4.setPreferredSize(new Dimension(450,350));
		scroll4.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll4.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll4.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder ));


		evacuator = new JPanel();
		evacuator.setBackground(Color.black);
		evacuator.setLayout(new GridLayout(20,1));
		JScrollPane scroll5 = new JScrollPane(evacuator);
		scroll5.setPreferredSize(new Dimension(450,350));
		scroll5.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll5.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll5.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder ));
		
		ei = new ImageIcon(getClass().getResource("images/bus.png"));
		el = new JLabel(ei);
		evacuator.add(el);

		gc = new JPanel();
		gc.setBackground(Color.black);
		gc.setLayout(new GridLayout(20,1));
		JScrollPane scroll6 = new JScrollPane(gc);
		scroll6.setPreferredSize(new Dimension(450,350));
		scroll6.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll6.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll6.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder ));
		iconImage = new ImageIcon(getClass().getResource("images/gasunit.png"));
		gcl = new JLabel(iconImage);
		gc.add(gcl);

		firetruck = new JPanel();
		firetruck.setBackground(Color.black);
		firetruck.setLayout(new GridLayout(20,1));
		JScrollPane scroll7 = new JScrollPane(firetruck);
		scroll7.setPreferredSize(new Dimension(450,350));
		scroll7.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll7.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll7.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder ));
		fti = new ImageIcon(getClass().getResource("images/fireunit.png"));
		ftl = new JLabel(fti);
		firetruck.add(ftl);

		information.setLayout(new GridLayout(5, 0));
		unit.add(scroll3);
		unit.add(scroll4);
		unit.add(scroll5);
		unit.add(scroll6);
		unit.add(scroll7);
	
		nextCycle = new JButton("Next Cycle");
		nextCycle.setBackground(Color.black);
		nextCycle.setForeground(Color.white);
		nextCycle.setFont(new Font("Times New Roman", Font.BOLD, 50));
		
		currentCycle = new JTextArea();
		currentCycle.setEditable(false);
		currentCycle.setBackground(Color.BLACK);
		currentCycle.setForeground(Color.white);
		currentCycle.setFont(new Font("Times New Roman", Font.BOLD, 50));
		
		respond = new JButton("Respond");
		respond.setBackground(Color.black);
		respond.setForeground(Color.white);
		respond.setFont(new Font("Times New Roman", Font.BOLD, 50));
		
		casualities = new JTextArea();
		casualities.setEditable(false);
		casualities.setBackground(Color.black);
		casualities.setForeground(Color.white);
		casualities.setFont(new Font("Times New Roman", Font.BOLD, 50));
		
	
		info= new JTextArea("Information: ");
		info.setBackground(Color.black);
		info.setForeground(Color.white);
		info.setEditable(false);
		info.setFont(new Font("Times New Roman", Font.BOLD, 40));
		
		disasters = new JTextArea("Disasters: ");
		disasters.setEditable(false);
		disasters.setFont(new Font("Times New Roman", Font.BOLD, 40));
		
		components5.add(nextCycle);
		components5.add(respond);
		components5.add(currentCycle);
		components5.add(casualities);
		
		activeDisasters = new JTextArea("Active Disasters: ");
		activeDisasters.setEditable(false);
		activeDisasters.setFont(new Font("Times New Roman", Font.BOLD, 40));
		
		deadPeople = new JTextArea("Dead Citizens: ");
		deadPeople.setEditable(false);
		deadPeople.setFont(new Font("Times New Roman", Font.BOLD, 40));
		
		JScrollPane scroll = new JScrollPane(info);
		scroll.setPreferredSize(new Dimension(500,350));
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder));
		
		JScrollPane scroll1 = new JScrollPane(activeDisasters);
		scroll1.setPreferredSize(new Dimension(500,350));
		scroll1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll1.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll1.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder));
		
		JScrollPane scroll2 = new JScrollPane(disasters);
		scroll2.setPreferredSize(new Dimension(500,350));
		scroll2.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll2.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll2.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder));
		
		JScrollPane scroll8 = new JScrollPane(deadPeople);
		scroll8.setPreferredSize(new Dimension(500,350));
		scroll8.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll8.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scroll8.setBorder(BorderFactory.createCompoundBorder(outsideBorder,insideBorder));
		
	
		
		information.add(components5);
		information.add(scroll2);
		information.add(scroll1);
		information.add(scroll8);
		information.add(scroll);
		
		
		getContentPane().add(gamepanel);
		validate();
		repaint();
		setVisible(true);
	}
	
	public void addButtonsToPannel() 
	{
		for (int i = 0; i < buttons.length; i++) {
			for(int j = 0; j <10; j++) {
			buttonsGrid.add(buttons[i][j]);
			}
		}
		repaint();
		validate();
	}	
}
