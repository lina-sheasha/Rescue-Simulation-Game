package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import simulation.Simulator;

public class GameOver extends JFrame{

	JTextArea title;
	JTextArea gameOver;
	Simulator s;
	public JTextArea noofcas = new JTextArea();
	
	public GameOver() 
	{	
		setVisible(true);
		setLayout(new FlowLayout());
		setTitle("GAME OVER");
		setLocation(0, 0);
		setSize(getWidth(), getHeight());
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		
//		ImageIcon image = new ImageIcon(getClass().getResource("images/background2.png"));
//		JLabel L1 = new JLabel(image);
//		L1.setOpaque(false);
		ImageIcon imageicon = new ImageIcon(getClass().getResource("images/zubat.png"));
		setIconImage(imageicon.getImage());
	
		this.setLayout(new GridLayout(4, 0));
		
		title = new JTextArea();
		title.setOpaque(false);
		title.setForeground(Color.BLACK);
		title.setEditable(false);
		title.setText("misery town");
		title.setFont(new Font("Spac3 tech", Font.BOLD, 420));
		setSize(getWidth(), getHeight());
		
		//JTextArea cas = new JTextArea();
	
		//cas.setText("" + casu);
	
		gameOver = new JTextArea();
		gameOver.setOpaque(false);
		gameOver.setBackground(Color.darkGray);
		gameOver.setForeground(Color.BLACK);
		gameOver.setEditable(false);
		gameOver.setText("game over");
		gameOver.setFont(new Font("Spac3 tech", Font.BOLD, 420));

		JPanel pictures = new JPanel();
		ImageIcon image2 = new ImageIcon(getClass().getResource("images/gameover.png"));
		JLabel L2 = new JLabel(image2);
		
		pictures.add(L2);
		getContentPane().add(title);
		getContentPane().add(gameOver);
		getContentPane().add(pictures);
	//	setContentPane(L1);
		setVisible(true);
		repaint();
		validate();
	}
	
	public static void main(String[] args) 
	{
		GameOver x = new GameOver();
	}
}
